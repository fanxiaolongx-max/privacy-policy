PR Audit Offline Workspace

1. Open "PR审计报告系统.html".
2. Import the snapshot zip/json in the same folder.
3. Continue the audit offline and export a new snapshot package after finishing.

1. 双击打开 “PR审计报告系统.html”。
2. 导入同目录中的快照 zip/json。
3. 审计完成后再导出新的快照包回传即可。