PR Audit Group Snapshot Bundle
Template: RFC PR
Group Field: 客户组织/Customer Org
Groups: 4

Each group folder includes a standalone offline HTML workspace and its own snapshot zip.
Send the corresponding group folder to the group owner.
The receiver opens the HTML file and imports the snapshot zip in the same folder.

每个分组文件夹都包含一份独立离线 HTML 工作台和对应快照 zip，可直接发给责任人继续处理。