// Versioned built-in template, copied from the user-approved Canva design.
// No signed URLs, account identifiers or runtime state are retained here.
const SOURCE_WIDTH = 1672;
const SOURCE_HEIGHT = 941;
export const VISION_ASSET_VERSION = 'hd-20261007-1';
export const visionElements = [
  {
    "kind": "image",
    "name": "画布背景",
    "asset": "MAHXOE_FPv4.png",
    "left": 0,
    "top": 0,
    "width": 1672,
    "height": 941,
    "z": 0
  },
  {
    "kind": "image",
    "name": "愿景远景",
    "asset": "MAHXODwRGRM.png",
    "top": 78,
    "left": 0,
    "width": 1672,
    "height": 197,
    "z": 1
  },
  {
    "kind": "image",
    "name": "视觉元素 3",
    "asset": "MAHXOPoXvYA.png",
    "top": 58,
    "left": 1552,
    "width": 81,
    "height": 21,
    "z": 2
  },
  {
    "kind": "image",
    "name": "四层能力平台",
    "asset": "MAHXOLuwbZY.png",
    "top": 196,
    "left": 159,
    "width": 1354,
    "height": 608,
    "z": 3
  },
  {
    "kind": "image",
    "name": "机关支撑卡片",
    "asset": "MAHXOJeYGSM.png",
    "top": 254,
    "left": 19,
    "width": 280,
    "height": 237,
    "z": 4
  },
  {
    "kind": "image",
    "name": "视觉元素 6",
    "asset": "MAHXOCwjeN8.png",
    "top": 333,
    "left": 59,
    "width": 41,
    "height": 20,
    "z": 5
  },
  {
    "kind": "image",
    "name": "视觉元素 7",
    "asset": "MAHXOFDTGD8.png",
    "top": 294,
    "left": 278,
    "width": 200,
    "height": 59,
    "z": 6
  },
  {
    "kind": "image",
    "name": "视觉元素 8",
    "asset": "MAHXOOrUj2A.png",
    "top": 372,
    "left": 278,
    "width": 140,
    "height": 60,
    "z": 7
  },
  {
    "kind": "image",
    "name": "地区部协同卡片",
    "asset": "MAHXOM2KwCE.png",
    "top": 254,
    "left": 1373,
    "width": 280,
    "height": 237,
    "z": 8
  },
  {
    "kind": "image",
    "name": "视觉元素 10",
    "asset": "MAHXOF4msL4.png",
    "top": 333,
    "left": 1413,
    "width": 60,
    "height": 20,
    "z": 9
  },
  {
    "kind": "image",
    "name": "视觉元素 11",
    "asset": "MAHXOIqa1-k.png",
    "top": 294,
    "left": 1194,
    "width": 200,
    "height": 59,
    "z": 10
  },
  {
    "kind": "image",
    "name": "视觉元素 12",
    "asset": "MAHXOOm0Iug.png",
    "top": 372,
    "left": 1254,
    "width": 140,
    "height": 60,
    "z": 11
  },
  {
    "kind": "image",
    "name": "视觉元素 13",
    "asset": "MAHXOOeU2Mg.png",
    "top": 803,
    "left": 39,
    "width": 479,
    "height": 80,
    "z": 12
  },
  {
    "kind": "image",
    "name": "视觉元素 14",
    "asset": "MAHXOOUQ_yw.png",
    "top": 803,
    "left": 119,
    "width": 81,
    "height": 80,
    "z": 13
  },
  {
    "kind": "image",
    "name": "视觉元素 15",
    "asset": "MAHXOEeM5JU.png",
    "top": 823,
    "left": 139,
    "width": 41,
    "height": 40,
    "z": 14
  },
  {
    "kind": "image",
    "name": "视觉元素 16",
    "asset": "MAHXOIfjujg.png",
    "top": 823,
    "left": 517,
    "width": 81,
    "height": 40,
    "z": 15
  },
  {
    "kind": "image",
    "name": "视觉元素 17",
    "asset": "MAHXOMRW3EE.png",
    "top": 901,
    "left": 59,
    "width": 519,
    "height": 21,
    "z": 16
  },
  {
    "kind": "image",
    "name": "视觉元素 18",
    "asset": "MAHXOOkMmdM.png",
    "top": 803,
    "left": 597,
    "width": 498,
    "height": 80,
    "z": 17
  },
  {
    "kind": "image",
    "name": "视觉元素 19",
    "asset": "MAHXODkAU4o.png",
    "top": 803,
    "left": 676,
    "width": 81,
    "height": 80,
    "z": 18
  },
  {
    "kind": "image",
    "name": "视觉元素 20",
    "asset": "MAHXOBkUaOM.png",
    "top": 823,
    "left": 696,
    "width": 41,
    "height": 40,
    "z": 19
  },
  {
    "kind": "image",
    "name": "视觉元素 21",
    "asset": "MAHXOB3hcu0.png",
    "top": 823,
    "left": 1094,
    "width": 81,
    "height": 40,
    "z": 20
  },
  {
    "kind": "image",
    "name": "视觉元素 22",
    "asset": "MAHXOGjbxo4.png",
    "top": 901,
    "left": 1094,
    "width": 519,
    "height": 21,
    "z": 21
  },
  {
    "kind": "image",
    "name": "视觉元素 23",
    "asset": "MAHXOIgLqCM.png",
    "top": 803,
    "left": 1154,
    "width": 479,
    "height": 80,
    "z": 22
  },
  {
    "kind": "image",
    "name": "视觉元素 24",
    "asset": "MAHXONTRz4M.png",
    "top": 803,
    "left": 1234,
    "width": 80,
    "height": 80,
    "z": 23
  },
  {
    "kind": "image",
    "name": "视觉元素 25",
    "asset": "MAHXOHqTVt8.png",
    "top": 823,
    "left": 1254,
    "width": 40,
    "height": 40,
    "z": 24
  },
  {
    "kind": "image",
    "name": "视觉元素 26",
    "asset": "MAHXODMznX0.png",
    "top": 274,
    "left": 577,
    "width": 80,
    "height": 79,
    "z": 25
  },
  {
    "kind": "image",
    "name": "视觉元素 27",
    "asset": "MAHXODcT3PQ.png",
    "top": 294,
    "left": 736,
    "width": 61,
    "height": 59,
    "z": 26
  },
  {
    "kind": "image",
    "name": "视觉元素 28",
    "asset": "MAHXOAlUKEc.png",
    "top": 294,
    "left": 875,
    "width": 61,
    "height": 59,
    "z": 27
  },
  {
    "kind": "image",
    "name": "视觉元素 29",
    "asset": "MAHXOH7V3pY.png",
    "top": 274,
    "left": 1015,
    "width": 80,
    "height": 79,
    "z": 28
  },
  {
    "kind": "image",
    "name": "视觉元素 30",
    "asset": "MAHXOEk9XI4.png",
    "top": 411,
    "left": 557,
    "width": 41,
    "height": 60,
    "z": 29
  },
  {
    "kind": "image",
    "name": "视觉元素 31",
    "asset": "MAHXOA4C-LQ.png",
    "top": 431,
    "left": 716,
    "width": 61,
    "height": 40,
    "z": 30
  },
  {
    "kind": "image",
    "name": "视觉元素 32",
    "asset": "MAHXOM31Qbs.png",
    "top": 431,
    "left": 875,
    "width": 81,
    "height": 40,
    "z": 31
  },
  {
    "kind": "image",
    "name": "视觉元素 33",
    "asset": "MAHXOE_h5xg.png",
    "top": 411,
    "left": 1054,
    "width": 61,
    "height": 60,
    "z": 32
  },
  {
    "kind": "image",
    "name": "视觉元素 34",
    "asset": "MAHXOIdbXdQ.png",
    "top": 509,
    "left": 477,
    "width": 81,
    "height": 60,
    "z": 33
  },
  {
    "kind": "image",
    "name": "视觉元素 35",
    "asset": "MAHXOGG-Fz0.png",
    "top": 548,
    "left": 696,
    "width": 61,
    "height": 60,
    "z": 34
  },
  {
    "kind": "image",
    "name": "视觉元素 36",
    "asset": "MAHXOCbMknw.png",
    "top": 548,
    "left": 915,
    "width": 61,
    "height": 60,
    "z": 35
  },
  {
    "kind": "image",
    "name": "视觉元素 37",
    "asset": "MAHXOADc3t8.png",
    "top": 509,
    "left": 1114,
    "width": 81,
    "height": 60,
    "z": 36
  },
  {
    "kind": "image",
    "name": "视觉元素 38",
    "asset": "MAHXOHfNFkw.png",
    "top": 646,
    "left": 457,
    "width": 101,
    "height": 80,
    "z": 37
  },
  {
    "kind": "image",
    "name": "视觉元素 39",
    "asset": "MAHXOA9t7SU.png",
    "top": 686,
    "left": 716,
    "width": 41,
    "height": 59,
    "z": 38
  },
  {
    "kind": "image",
    "name": "视觉元素 40",
    "asset": "MAHXOBJWkOg.png",
    "top": 686,
    "left": 895,
    "width": 81,
    "height": 59,
    "z": 39
  },
  {
    "kind": "image",
    "name": "视觉元素 41",
    "asset": "MAHXOL4pHmE.png",
    "top": 646,
    "left": 1114,
    "width": 101,
    "height": 80,
    "z": 40
  },
  {
    "kind": "text",
    "name": "让维护责任回归一线，让自主履行成为常态",
    "text": "让维护责任回归一线，让自主履行成为常态",
    "top": 8.45999974431038,
    "left": 39.490571051227846,
    "width": 949.3803948772196,
    "height": 57.26067703125,
    "fontSize": 47.72,
    "bold": true,
    "color": "#c7000b",
    "z": 100
  },
  {
    "kind": "text",
    "name": "机关",
    "text": "机关",
    "top": 299.1516408029944,
    "left": 58.22609375508464,
    "width": 55.51562449153589,
    "height": 31.135693359375,
    "fontSize": 25.95,
    "bold": true,
    "color": "#c7000b",
    "z": 100
  },
  {
    "kind": "text",
    "name": "标准与机制建设\n专业能力与重大问题支撑",
    "text": "标准与机制建设\n专业能力与重大问题支撑",
    "top": 366.5918988913298,
    "left": 49.126727186903665,
    "width": 219.74654562619267,
    "height": 49.882421875,
    "fontSize": 20.78,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "地区部",
    "text": "地区部",
    "top": 299.1516408029944,
    "left": 1427.061796882627,
    "width": 83.27343673730384,
    "height": 31.135693359375,
    "fontSize": 25.95,
    "bold": true,
    "color": "#c7000b",
    "z": 100
  },
  {
    "kind": "text",
    "name": "资源统筹与跨国协同\n重点风险与履行监督",
    "text": "资源统筹与跨国协同\n重点风险与履行监督",
    "top": 366.5918988913298,
    "left": 1426.096604944492,
    "width": 179.7926305508127,
    "height": 49.882421875,
    "fontSize": 20.78,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "资源协同",
    "text": "资源协同",
    "top": 314.2398472536355,
    "left": 1294.9709311377028,
    "width": 66.5787612297097,
    "height": 18.205859375,
    "fontSize": 15.17,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "近期 | 看得清",
    "text": "近期 | 看得清",
    "top": 817.1971197245642,
    "left": 211.80498028470547,
    "width": 127.7050965294546,
    "height": 24.5330078125,
    "fontSize": 20.44,
    "bold": true,
    "color": "#c7000b",
    "z": 100
  },
  {
    "kind": "text",
    "name": "中期 | 闭得住",
    "text": "中期 | 闭得住",
    "top": 817.1971197245642,
    "left": 775.1252927847055,
    "width": 127.7050965294546,
    "height": 24.5330078125,
    "fontSize": 20.44,
    "bold": true,
    "color": "#c7000b",
    "z": 100
  },
  {
    "kind": "text",
    "name": "远期 | 持续自主",
    "text": "远期 | 持续自主",
    "top": 817.1971197245642,
    "left": 1338.2235094314935,
    "width": 149.91468185064744,
    "height": 24.5330078125,
    "fontSize": 20.44,
    "bold": true,
    "color": "#c7000b",
    "z": 100
  },
  {
    "kind": "text",
    "name": "代表处维护业务自主履行",
    "text": "代表处维护业务自主履行",
    "top": 137.99888246366322,
    "left": 639.8182755343768,
    "width": 379.56215508130134,
    "height": 38.9935871875,
    "fontSize": 32.49,
    "bold": true,
    "color": "#c7000b",
    "z": 100
  },
  {
    "kind": "text",
    "name": "责任在一线 ｜ 风险早化解 ｜ 服务有韧性 ｜ ",
    "text": "责任在一线 ｜ 风险早化解 ｜ 服务有韧性 ｜ 价值可持续",
    "top": 184.84674399588258,
    "left": 583.3977242416265,
    "width": 492.403307496285,
    "height": 22.18583984375,
    "fontSize": 18.49,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "风险态势 · 服务质量 · 经营价值 · 人员能",
    "text": "风险态势 · 服务质量 · 经营价值 · 人员能力",
    "top": 529.1996098616161,
    "left": 660.2895486622441,
    "width": 338.6196586550498,
    "height": 18.12421875,
    "fontSize": 15.1,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "事实可见 · 标准一致 · 责任清晰 · 证据可",
    "text": "事实可见 · 标准一致 · 责任清晰 · 证据可溯",
    "top": 666.9681645491161,
    "left": 660.2895486622441,
    "width": 338.6196586550498,
    "height": 18.12421875,
    "fontSize": 15.1,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "人是责任主体，数据、平台与AI是支撑手段",
    "text": "人是责任主体，数据、平台与AI是支撑手段",
    "top": 763.461553424783,
    "left": 601.2160360326573,
    "width": 456.7666340847405,
    "height": 26.410742187500002,
    "fontSize": 22.01,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "以客户网络稳定、服务质量提升和经营价值兑现为共同",
    "text": "以客户网络稳定、服务质量提升和经营价值兑现为共同目标",
    "top": 894.2979446902871,
    "left": 582.2449338971352,
    "width": 494.7089380147506,
    "height": 20.900000000000002,
    "fontSize": 17.42,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "代表处自主履行 · 地区部协同统筹 · 机关专业",
    "text": "代表处自主履行 · 地区部协同统筹 · 机关专业支撑",
    "top": 73.079185,
    "left": 53.8828125,
    "width": 619.65234375,
    "height": 30.685380000000002,
    "fontSize": 25.57,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "一线主责 · 分级响应 · 专家会诊 · 重大事",
    "text": "一线主责 · 分级响应 · 专家会诊 · 重大事项升级",
    "top": 406.58559618974107,
    "left": 643.6448490753465,
    "width": 371.9090329141033,
    "height": 18.12421875,
    "fontSize": 15.1,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "主动发现 · 自主研判 · 及时处置 · 复盘改",
    "text": "主动发现 · 自主研判 · 及时处置 · 复盘改进",
    "top": 271.57241259599107,
    "left": 660.2895486622441,
    "width": 338.6196586550498,
    "height": 18.12421875,
    "fontSize": 15.1,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "未来3—5年愿景构想",
    "text": "未来3—5年愿景构想",
    "top": 26.35605015903711,
    "left": 1446.7781466689644,
    "width": 171.3214531844976,
    "height": 20.900000000000002,
    "fontSize": 17.42,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "经验复用 · 持续优化",
    "text": "经验复用 · 持续优化",
    "top": 846.0672879980877,
    "left": 1337.9391277414195,
    "width": 178.35285085804608,
    "height": 20.736718749999998,
    "fontSize": 17.28,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "事实贯通 · 责任到人",
    "text": "事实贯通 · 责任到人",
    "top": 846.0672879980877,
    "left": 211.29850274141955,
    "width": 178.35285085804608,
    "height": 20.736718749999998,
    "fontSize": 17.28,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "风险前移 · 协同闭环",
    "text": "风险前移 · 协同闭环",
    "top": 846.0672879980877,
    "left": 774.6188152414195,
    "width": 178.35285085804608,
    "height": 20.736718749999998,
    "fontSize": 17.28,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "自主闭环",
    "text": "自主闭环",
    "top": 241.5337646484375,
    "left": 786.19921875,
    "width": 244.921875,
    "height": 29.931494140625002,
    "fontSize": 24.94,
    "bold": true,
    "color": "#c7000b",
    "z": 100
  },
  {
    "kind": "text",
    "name": "可信基础",
    "text": "可信基础",
    "top": 636.9295166015625,
    "left": 786.19921875,
    "width": 244.921875,
    "height": 29.931494140625002,
    "fontSize": 24.94,
    "bold": true,
    "color": "#c7000b",
    "z": 100
  },
  {
    "kind": "text",
    "name": "协同履责",
    "text": "协同履责",
    "top": 373.7915771484375,
    "left": 786.19921875,
    "width": 244.921875,
    "height": 29.931494140625002,
    "fontSize": 24.94,
    "bold": true,
    "color": "#c7000b",
    "z": 100
  },
  {
    "kind": "text",
    "name": "运营洞察",
    "text": "运营洞察",
    "top": 499.1609619140625,
    "left": 786.19921875,
    "width": 244.921875,
    "height": 29.931494140625002,
    "fontSize": 24.94,
    "bold": true,
    "color": "#c7000b",
    "z": 100
  },
  {
    "kind": "text",
    "name": "专业支撑",
    "text": "专业支撑",
    "top": 314.2398472536355,
    "left": 310.3849936377029,
    "width": 66.5787612297097,
    "height": 18.205859375,
    "fontSize": 15.17,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "机制保障",
    "text": "机制保障",
    "top": 406.5447788942605,
    "left": 310.3849936377029,
    "width": 66.5787612297097,
    "height": 18.205859375,
    "fontSize": 15.17,
    "bold": false,
    "color": "#293746",
    "z": 100
  },
  {
    "kind": "text",
    "name": "风险与整改",
    "text": "风险与整改",
    "left": 457.5,
    "top": 565,
    "width": 120,
    "height": 28,
    "fontSize": 18,
    "bold": false,
    "color": "#30485b",
    "align": "center",
    "z": 100
  },
  {
    "kind": "text",
    "name": "响应与恢复",
    "text": "响应与恢复",
    "left": 666.5,
    "top": 604,
    "width": 120,
    "height": 28,
    "fontSize": 18,
    "bold": false,
    "color": "#30485b",
    "align": "center",
    "z": 100
  },
  {
    "kind": "text",
    "name": "收入与利润",
    "text": "收入与利润",
    "left": 885.5,
    "top": 604,
    "width": 120,
    "height": 28,
    "fontSize": 18,
    "bold": false,
    "color": "#30485b",
    "align": "center",
    "z": 100
  },
  {
    "kind": "text",
    "name": "能力与履职",
    "text": "能力与履职",
    "left": 1094.5,
    "top": 565,
    "width": 120,
    "height": 28,
    "fontSize": 18,
    "bold": false,
    "color": "#30485b",
    "align": "center",
    "z": 100
  },
  {
    "kind": "text",
    "name": "监督指导",
    "text": "监督指导",
    "left": 1294.97,
    "top": 406.54,
    "width": 66.58,
    "height": 18.21,
    "fontSize": 15.17,
    "bold": false,
    "color": "#5b6978",
    "z": 100
  }
];
const escapeHtml = value => String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
// Update only our built-in pictures; preserve user replacements and all geometry.
export function refreshVisionAssetUrls(root) {
    const base = new URL('../assets/vision/', import.meta.url);
    const paths = new Set(visionElements.filter(el => el.kind === 'image').map(el => base.pathname + el.asset));
    let changed = 0;
    root.querySelectorAll('.vision-template .vision-visual img').forEach(img => {
        const src = img.getAttribute('src');
        if (!src) return;
        let url;
        try { url = new URL(src, base); } catch (_) { return; }
        if (url.origin !== base.origin || !paths.has(url.pathname)) return;
        if (url.searchParams.get('v') === VISION_ASSET_VERSION) return;
        url.searchParams.set('v', VISION_ASSET_VERSION);
        img.setAttribute('src', `${url.pathname}${url.search}${url.hash}`);
        changed++;
    });
    return changed;
}
export function createVisionSlide(id = 'vision-content') {
    const sx = 1920 / SOURCE_WIDTH, sy = 1080 / SOURCE_HEIGHT;
    const html = visionElements.map((el, index) => {
        const geometry = `position:absolute;left:${el.left*sx}px;top:${el.top*sy}px;width:${el.width*sx}px;height:${el.height*sy}px;z-index:${el.z};`;
        const common = `class="template-component vision-element${el.kind === 'text' ? ' vision-text editable template-editable' : ' vision-visual'}" data-component-name="${escapeHtml(el.name)}" data-vision-kind="${el.kind}" data-vision-id="vision-${index}"`;
        if (el.kind === 'text') return `<div ${common} contenteditable="true" style="${geometry}font-size:${Math.min(el.fontSize, el.width / Math.max(...el.text.split("\n").map(line => Array.from(line).length)) * 0.96)*sx}px;font-weight:${el.bold ? 700 : 400};color:${el.color};text-align:${el.align || 'left'};line-height:1.2;">${escapeHtml(el.text).replace(/\n/g,'<br>')}</div>`;
        const src = new URL(`../assets/vision/${el.asset}`, import.meta.url).pathname + `?v=${VISION_ASSET_VERSION}`;
        return `<div ${common} style="${geometry}"><img src="${escapeHtml(src)}" alt="${escapeHtml(el.name)}" draggable="false" style="width:100%;height:100%;object-fit:fill;display:block;" /></div>`;
    }).join('');
    return {id, layout:'custom', html:`<div class="vision-template" data-template-version="vision-20261006">${html}</div>`};
}
